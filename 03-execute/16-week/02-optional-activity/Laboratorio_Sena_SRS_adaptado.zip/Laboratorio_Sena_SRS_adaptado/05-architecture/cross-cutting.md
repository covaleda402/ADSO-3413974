# Cross-Cutting Concerns

> Estado: 🔴 | Última actualización: 2026-06-16

## Aspectos transversales

### Seguridad

El acceso al sistema debe estar protegido mediante autenticación con usuario y contraseña. Las contraseñas deben almacenarse de forma cifrada.

### Rendimiento

Las operaciones principales del sistema deben responder en un tiempo inferior a tres segundos en condiciones normales de uso.

### Usabilidad

La interfaz debe ser sencilla e intuitiva para usuarios con conocimientos básicos de tecnología.

### Disponibilidad

El sistema debe funcionar sin conexión a internet, almacenando la información localmente.

### Respaldo de información

El sistema debe generar automáticamente una copia de seguridad de la base de datos al finalizar la jornada.

### Control de acceso

El sistema debe diferenciar los permisos entre los roles de administrador y cajero para proteger la información y las funciones del sistema.
