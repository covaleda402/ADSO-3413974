# ADR-001: Aplicación de escritorio con funcionamiento offline

**Estado:** ACCEPTED

**Fecha:** 2026-07-03

**Autores:** Equipo 3

---

## Contexto

El Supermercado La Esquina requiere un sistema que permita registrar ventas, administrar el inventario, gestionar proveedores y generar reportes sin depender de una conexión permanente a Internet. Debido a que el negocio opera de forma presencial y con recursos tecnológicos básicos, es necesario garantizar la disponibilidad del sistema en todo momento.

## Decisión

Se decidió desarrollar el sistema como una aplicación de escritorio con funcionamiento offline y almacenamiento local de la información.

Esta decisión permite que las operaciones principales del negocio continúen funcionando aun cuando no exista conexión a Internet, asegurando la disponibilidad del sistema y un mejor rendimiento para los usuarios.

## Consecuencias

### Positivas

- El sistema funciona sin conexión a Internet.
- Mayor velocidad de respuesta al trabajar con datos locales.
- Menor dependencia de servicios externos.
- Fácil implementación para un negocio pequeño.

### Negativas / Trade-offs

- No permite acceso remoto a la información.
- Las copias de seguridad deben realizarse de forma local.
- La sincronización entre varios equipos requerirá una solución futura.

## Alternativas consideradas

- Aplicación web.
- Aplicación híbrida.
- Sistema completamente en la nube.

Estas alternativas fueron descartadas porque requieren conexión permanente a Internet y una infraestructura mayor a la necesaria para el alcance del proyecto.