# ADR-002: Arquitectura modular del sistema

**Estado:** ACCEPTED

**Fecha:** 2026-07-03

**Autores:** Equipo 3

---

## Contexto

El sistema debe administrar diferentes procesos del Supermercado La Esquina, como ventas, inventario, proveedores, reportes y autenticación. Cada uno cumple funciones distintas, pero deben trabajar de manera integrada.

## Decisión

Se decidió organizar el sistema mediante una arquitectura modular, separando las funcionalidades en módulos independientes según su responsabilidad.

Los módulos definidos son:

- Ventas
- Inventario
- Proveedores
- Reportes
- Autenticación

Cada módulo tendrá responsabilidades específicas y se comunicará con los demás únicamente cuando sea necesario.

## Consecuencias

### Positivas

- Mayor organización del código.
- Facilita el mantenimiento.
- Permite agregar nuevas funcionalidades sin afectar todo el sistema.
- Favorece el trabajo colaborativo.

### Negativas / Trade-offs

- Requiere definir claramente las responsabilidades de cada módulo.
- Puede aumentar ligeramente la complejidad del diseño inicial.

## Alternativas consideradas

- Desarrollar toda la lógica en un único módulo.

Esta alternativa fue descartada porque dificultaría el mantenimiento y el crecimiento del sistema.
