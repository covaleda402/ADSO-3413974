# ADR-003: Control de acceso basado en roles

**Estado:** ACCEPTED

**Fecha:** 2026-07-03

**Autores:** Equipo 3

---

## Contexto

El sistema será utilizado por diferentes tipos de usuarios, cada uno con responsabilidades específicas dentro del Supermercado La Esquina. Es necesario controlar el acceso a las funcionalidades para proteger la información y evitar modificaciones no autorizadas.

## Decisión

Se decidió implementar un control de acceso basado en roles (RBAC), asignando permisos de acuerdo con las funciones de cada usuario.

Los roles definidos son:

- **Administrador:** acceso completo a ventas, inventario, proveedores, reportes y configuración del sistema.
- **Cajero:** acceso al registro de ventas, consulta de productos y emisión de comprobantes.

Cada usuario solo podrá acceder a las funcionalidades autorizadas para su rol.

## Consecuencias

### Positivas

- Mayor seguridad de la información.
- Reduce el riesgo de modificaciones accidentales.
- Facilita la administración de permisos.
- Permite controlar las responsabilidades de cada usuario.

### Negativas / Trade-offs

- Requiere gestionar usuarios y permisos.
- Será necesario autenticar a cada usuario antes de utilizar el sistema.

## Alternativas consideradas

- Permitir acceso completo a todos los usuarios.

Esta alternativa fue descartada porque aumenta el riesgo de errores y compromete la seguridad del sistema.