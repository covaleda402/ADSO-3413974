# ADR-004: Uso de una base de datos relacional

**Estado:** ACCEPTED

**Fecha:** 2026-07-03

**Autores:** Equipo 3

---

## Contexto

El sistema debe almacenar información relacionada con productos, ventas, inventario, proveedores y usuarios. Estos datos presentan relaciones entre sí y deben mantenerse consistentes durante la operación del sistema.

## Decisión

Se decidió utilizar una base de datos relacional para almacenar la información del sistema, garantizando la integridad de los datos mediante relaciones entre las diferentes entidades.

La base de datos permitirá gestionar de forma organizada toda la información necesaria para el funcionamiento del sistema.

## Consecuencias

### Positivas

- Mantiene la integridad y consistencia de los datos.
- Facilita las consultas y la generación de reportes.
- Reduce la duplicidad de información.
- Permite un crecimiento ordenado del sistema.

### Negativas / Trade-offs

- Requiere un diseño adecuado del modelo de datos.
- Las modificaciones estructurales pueden requerir migraciones de la base de datos.

## Alternativas consideradas

- Utilizar archivos planos para almacenar la información.
- Utilizar una base de datos NoSQL.

Estas alternativas fueron descartadas porque el sistema maneja información altamente estructurada y con múltiples relaciones entre las entidades.