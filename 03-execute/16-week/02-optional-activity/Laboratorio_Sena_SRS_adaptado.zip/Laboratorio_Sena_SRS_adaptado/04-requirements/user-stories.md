# User Stories

> Estado: 🔴 | Última actualización: 2026-06-16

## Historias de usuario

### US-01 Registrar venta

**Como** cajero, **quiero** registrar una venta, **para** calcular automáticamente el total y el cambio.

### US-02 Buscar producto

**Como** cajero, **quiero** buscar un producto por nombre o código, **para** encontrarlo rápidamente durante la venta.

### US-03 Emitir comprobante

**Como** cajero, **quiero** generar un comprobante al finalizar una venta, **para** entregarlo al cliente.

### US-04 Consultar inventario

**Como** administrador, **quiero** consultar el inventario, **para** conocer la disponibilidad de los productos.

### US-05 Actualizar inventario

**Como** administrador, **quiero** que se actualice automáticamente el stock después de una venta, **para** mantener el inventario actualizado.

### US-06 Gestionar proveedores

**Como** administrador, **quiero** registrar y administrar proveedores, **para** mantener organizada la información de abastecimiento.

### US-07 Registrar pedidos

**Como** administrador, **quiero** registrar pedidos a proveedores, **para** llevar un control de las compras realizadas.

### US-08 Generar reportes

**Como** administrador, **quiero** generar reportes de ventas, **para** apoyar la toma de decisiones del negocio.
