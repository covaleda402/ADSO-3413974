# Non-Functional Requirements

> Estado: 🔴 | Última actualización: 2026-06-16

## Requerimientos no funcionales

### RNF-01 Usabilidad

La interfaz debe ser fácil de usar para usuarios con conocimientos básicos de tecnología. Las tareas principales deben completarse en un máximo de tres clics desde la pantalla principal.

### RNF-02 Disponibilidad

El sistema debe funcionar sin conexión a internet, almacenando la información de forma local.

### RNF-03 Rendimiento

El tiempo de respuesta de las operaciones principales no debe superar los tres segundos en condiciones normales de uso.

### RNF-04 Seguridad

El acceso al sistema debe estar protegido mediante usuario y contraseña. Las contraseñas deben almacenarse de forma cifrada.

### RNF-05 Confiabilidad

El sistema debe generar automáticamente una copia de seguridad de la base de datos al finalizar la jornada.
