# Traceability Matrix

> Estado: 🔴 | Última actualización: 2026-06-16

## Matriz de trazabilidad

| Requerimiento                        | Caso de Uso                              | Módulo      |
| ------------------------------------ | ---------------------------------------- | ----------- |
| RF-01 Registrar venta                | CU-001 Registrar una venta               | Ventas      |
| RF-02 Buscar producto                | CU-001 Registrar una venta               | Ventas      |
| RF-03 Emitir comprobante             | CU-001 Registrar una venta               | Ventas      |
| RF-04 Anular venta                   | No definido                              | Ventas      |
| RF-05 Consultar stock                | CU-002 Consultar inventario              | Inventario  |
| RF-06 Actualizar stock               | CU-001 Registrar una venta               | Inventario  |
| RF-07 Alerta de stock mínimo         | CU-002 Consultar inventario              | Inventario  |
| RF-08 Registrar entrada de mercancía | CU-004 Registrar proveedor y pedido      | Inventario  |
| RF-09 Gestionar proveedores          | CU-004 Registrar proveedor y pedido      | Proveedores |
| RF-10 Historial de pedidos           | CU-004 Registrar proveedor y pedido      | Proveedores |
| RF-11 Reporte diario                 | CU-003 Generar reporte de cierre del día | Reportes    |
| RF-12 Reporte mensual                | CU-003 Generar reporte de cierre del día | Reportes    |
