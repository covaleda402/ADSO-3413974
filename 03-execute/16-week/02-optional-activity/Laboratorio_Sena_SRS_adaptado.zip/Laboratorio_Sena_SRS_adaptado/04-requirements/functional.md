# Functional Requirements

> Estado: 🔴 | Última actualización: 2026-06-16

## Requerimientos funcionales

### RF-01 Registrar venta

El sistema debe permitir registrar ventas calculando automáticamente subtotales, total y cambio.

### RF-02 Buscar producto

El sistema debe permitir buscar productos por nombre o código.

### RF-03 Emitir comprobante

El sistema debe generar un comprobante al finalizar cada venta.

### RF-04 Anular venta

El administrador debe poder anular ventas del mismo día.

### RF-05 Consultar stock

El sistema debe permitir consultar el inventario en tiempo real.

### RF-06 Actualizar stock

El inventario debe actualizarse automáticamente después de cada venta.

### RF-07 Alerta de stock mínimo

El sistema debe generar alertas cuando un producto alcance el stock mínimo.

### RF-08 Registrar entrada de mercancía

El sistema debe permitir registrar la recepción de productos provenientes de proveedores.

### RF-09 Gestionar proveedores

El sistema debe permitir crear, editar y consultar proveedores.

### RF-10 Consultar historial de pedidos

El sistema debe registrar y consultar el historial de pedidos realizados a los proveedores.

### RF-11 Generar reporte diario

El administrador debe poder generar reportes diarios de ventas.

### RF-12 Generar reporte mensual

El administrador debe poder generar reportes mensuales de ventas.
