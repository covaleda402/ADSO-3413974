# risks

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

<!-- Contenido pendiente -->

## Riesgos identificados

| Riesgo | Impacto | Mitigación |
|---------|---------|------------|
| Pérdida de información | Alto | Copias de seguridad periódicas |
| Errores de desarrollo | Medio | Revisiones de código y pruebas |
| Cambios en los requisitos | Medio | Gestión de cambios |
| Fallos del equipo | Alto | Plan de recuperación y respaldos |