# dependencies

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

<!-- Contenido pendiente -->

## Dependencias

- Git
- GitHub
- Visual Studio Code
- Motor de base de datos
- Sistema operativo Windows 10 o superior

Estas herramientas son necesarias para el desarrollo y funcionamiento del proyecto.