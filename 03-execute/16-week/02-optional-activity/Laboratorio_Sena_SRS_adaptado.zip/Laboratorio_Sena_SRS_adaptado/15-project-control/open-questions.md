## Flujo de resolución

1. **Registrar:** cualquier equipo puede agregar una pregunta abierta con estado `ABIERTA`.
2. **Asignar:** el equipo de arquitectura o gestión asigna un responsable y una fecha límite de respuesta.
3. **Resolver:** el responsable responde y cambia el estado a `RESUELTA`.
4. **Escalar si aplica:** si la resolución genera una decisión técnica relevante, crear un ADR en `05-architecture/decisions/records/`. Si afecta requisitos, actualizar `04-requirements/`.
5. **Cerrar:** las preguntas resueltas se mantienen en el historial para consulta futura.

## Formato de registro

| # | Pregunta | Área | Responsable | Fecha límite | Estado | Resolución / ADR |
|---|----------|------|-------------|--------------|--------|------------------|

## Estados válidos

| Estado | Significado |
|--------|-------------|
| `ABIERTA` | Sin respuesta aún |
| `EN REVISIÓN` | Responsable asignado, trabajando en ella |
| `RESUELTA` | Tiene respuesta, puede generar ADR o actualización |
| `CANCELADA` | Ya no aplica (indicar por qué) |

---

## Preguntas abiertas

| # | Pregunta | Área | Responsable | Fecha límite | Estado | Resolución / ADR |
|---|----------|------|-------------|--------------|--------|------------------|
| 1 | ¿Se implementará la facturación electrónica (DIAN) en una versión futura del sistema? | Requisitos | Equipo 3 | 2026-07-31 | ABIERTA | Pendiente de definir para la versión 2.0 |

---

## Resueltas

| # | Pregunta | Área | Resolución | ADR / Doc relacionado |
|---|----------|------|------------|-----------------------|
| 1 | ¿El sistema funcionará sin conexión a Internet? | Arquitectura | Se definió una aplicación de escritorio con funcionamiento offline. | ADR-001 |
| 2 | ¿Cómo se organizarán las funcionalidades del sistema? | Arquitectura | Se adoptó una arquitectura modular por responsabilidades. | ADR-002 |
| 3 | ¿Cómo se controlará el acceso al sistema? | Seguridad | Se implementará control de acceso basado en roles (Administrador y Cajero). | ADR-003 |
| 4 | ¿Qué tipo de base de datos utilizará el sistema? | Datos | Se utilizará una base de datos relacional para garantizar la integridad de la información. | ADR-004 |