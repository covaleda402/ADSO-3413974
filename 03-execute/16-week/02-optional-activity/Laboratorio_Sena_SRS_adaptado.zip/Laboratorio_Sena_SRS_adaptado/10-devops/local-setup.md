# local-setup

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

<!-- Contenido pendiente -->

## Requisitos

- Sistema operativo Windows 10 o superior.
- Visual Studio Code.
- Git.
- Motor de base de datos utilizado por el proyecto.

## Configuración

1. Clonar el repositorio.
2. Abrir el proyecto en Visual Studio Code.
3. Configurar la base de datos local.
4. Crear los usuarios iniciales.
5. Ejecutar la aplicación.

## Verificación

Comprobar que:

- El sistema inicia correctamente.
- Es posible iniciar sesión.
- Se pueden registrar productos y ventas.
- La información se almacena correctamente.