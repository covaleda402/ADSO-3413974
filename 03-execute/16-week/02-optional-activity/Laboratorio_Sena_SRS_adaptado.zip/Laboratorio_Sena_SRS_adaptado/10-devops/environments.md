# environments

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

<!-- Contenido pendiente -->
| Entorno | Descripción |
|---------|-------------|
| Desarrollo | Ambiente utilizado por el equipo para implementar y probar nuevas funcionalidades. |
| Pruebas | Ambiente destinado a verificar el correcto funcionamiento del sistema antes de su entrega. |
| Producción | Ambiente instalado en el Supermercado La Esquina para el uso diario del sistema. |