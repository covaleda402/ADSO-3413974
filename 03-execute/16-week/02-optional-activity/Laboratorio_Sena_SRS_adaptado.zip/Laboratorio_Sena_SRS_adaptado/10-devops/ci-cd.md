# ci-cd

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

<!-- Contenido pendiente -->

## Objetivo

Definir el proceso de integración y despliegue continuo para el Sistema de Gestión Comercial del Supermercado La Esquina.

## Integración continua (CI)

Durante el desarrollo se realizarán las siguientes actividades:

- Validación del código fuente.
- Revisión de cambios antes de su integración.
- Ejecución de pruebas cuando estén disponibles.
- Control de versiones mediante Git.

## Despliegue continuo (CD)

El despliegue consistirá en:

- Generar una versión estable del sistema.
- Instalar la aplicación en el equipo del supermercado.
- Configurar la base de datos.
- Verificar el correcto funcionamiento del sistema.

## Herramientas

- Git
- GitHub
- Visual Studio Code

## Resultado esperado

Mantener un proceso controlado para integrar cambios y facilitar futuras actualizaciones del sistema.