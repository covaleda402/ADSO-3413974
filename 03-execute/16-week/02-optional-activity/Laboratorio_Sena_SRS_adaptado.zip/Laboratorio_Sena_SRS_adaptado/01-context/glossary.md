# Glosario

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

# Glossary

> Estado: 🔴 | Última actualización: 2026-06-16

## Términos

### SRS (Software Requirements Specification)
Documento que describe los requisitos funcionales y no funcionales de un sistema de software.

### Requisito Funcional (RF)
Funcionalidad que el sistema debe ofrecer para satisfacer las necesidades del negocio.

### Requisito No Funcional (RNF)
Característica de calidad del sistema, como rendimiento, seguridad, disponibilidad o usabilidad.

### Requisito de Negocio (RN)
Necesidad u objetivo del negocio que el sistema debe ayudar a cumplir.

### Caso de Uso (CU)
Descripción de la interacción entre un actor y el sistema para lograr un objetivo específico.

### Actor
Persona o entidad que interactúa con el sistema.

### Inventario
Conjunto de productos disponibles para la venta en el supermercado.

### Stock
Cantidad disponible de un producto en el inventario.

### Proveedor
Persona o empresa encargada de suministrar productos al supermercado.

### MVP (Minimum Viable Product)
Primera versión del sistema que incluye únicamente las funcionalidades esenciales.
