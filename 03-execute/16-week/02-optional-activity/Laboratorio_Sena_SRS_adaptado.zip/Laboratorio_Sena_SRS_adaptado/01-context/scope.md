# Scope

> Estado: 🔴 | Última actualización: 2026-06-16

## Alcance del proyecto

El proyecto tiene como objetivo desarrollar un sistema de gestión comercial para el Supermercado La Esquina que permita automatizar los procesos de ventas, control de inventario y gestión de proveedores.

## Incluye

* Registro y consulta de ventas.
* Cálculo automático de totales y cambio.
* Control de inventario con actualización automática del stock.
* Alertas de stock mínimo.
* Registro y consulta de proveedores.
* Historial de pedidos.
* Reportes básicos de ventas diarias y mensuales.
* Control de acceso con roles de administrador y cajero.

## Fuera del alcance

* Facturación electrónica (DIAN).
* Integración con datáfonos o pasarelas de pago.
* Aplicación móvil.
* Versión web.
* Gestión de clientes frecuentes o programas de fidelización.


