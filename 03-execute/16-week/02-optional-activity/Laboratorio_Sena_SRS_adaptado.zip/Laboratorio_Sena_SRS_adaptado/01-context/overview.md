# Overview

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Contexto institucional

El supermercado La Esquina del señor Carlos R. y su esposa Martha R. Opera de Lunes a Domingo atendiendo entre 40 y 60 clientes diarios, con un catalogo de aproximadamente 90 productos de consumo masivo (alimentos, aseo, bebidas, etc). El equipo esta conformado por el dueño, la cajera principal y un empleado de apoyo en bodega, al momento de realizar el levantamiento de esta informacion en el negocio todo se hacia con un manejo manual(cuaderno y calculadora)

## Problema

El supermercado opera de manera completamente manual, generando ineficiencias operativas, errores de cobro recurrentes y perdida de informacion valiosa para la toma de decisiones. Los problemas documentados son:
•	El proceso de venta tarda entre 3 y 4.5 minutos por cliente debido al calculo manual de precios.
•	Errores frecuentes de cobro y cambio generan perdidas economicas y mala experiencia al cliente.
•	No existe control de inventario en tiempo real: el desabastecimiento se detecta solo cuando el producto ya se agoto.
•	La gestion de proveedores es completamente informal, basada en memoria y facturas fisicas desordenadas.
•	No es posible generar reportes de ventas ni estadisticas del negocio para la toma de decisiones.


## Objetivos

Desarrollar un sistema de software de escritorio que automatice los procesos de ventas, control de inventario y gestion de proveedores del Supermercado La Esquina, con el fin de reducir los errores operativos, optimizar el tiempo de atencion al cliente y proveer informacion oportuna para la toma de decisiones del administrador.

## Referencias

- Documento SRS del proyecto Gestion Comercial.
- Acuerdo 009 de 2024.
