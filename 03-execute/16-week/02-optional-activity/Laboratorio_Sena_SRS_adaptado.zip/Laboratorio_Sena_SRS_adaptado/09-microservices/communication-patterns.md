# Patrones de comunicación

> Estado: 🟢 Completado | Última actualización: 2026-07-03
> Autor: Equipo 3 | Equipo: Equipo 3

## Síncrona (REST / gRPC)

El sistema utiliza comunicación síncrona entre sus módulos internos. Al tratarse de una aplicación de escritorio monolítica, las operaciones se realizan mediante llamadas internas sin necesidad de servicios REST o gRPC.

## Asíncrona (eventos)

En la versión actual del sistema no se implementa comunicación basada en eventos ni mensajería asíncrona. Todas las operaciones se ejecutan de forma inmediata durante la interacción del usuario con el sistema.

## Resiliencia

Para garantizar la estabilidad del sistema se implementarán las siguientes medidas:

- Validación de datos de entrada.
- Manejo de excepciones.
- Control de errores durante las operaciones.
- Copias de seguridad periódicas de la base de datos.
- Recuperación ante fallos mediante restauración de respaldos.