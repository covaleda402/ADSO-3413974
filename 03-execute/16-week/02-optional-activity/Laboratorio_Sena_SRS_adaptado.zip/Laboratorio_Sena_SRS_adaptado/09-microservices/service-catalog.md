# Catálogo de servicios

| Servicio | Descripción | Owner | Repo | Estado |
|----------|-------------|-------|------|--------|
| Autenticación | Gestiona el acceso de usuarios y la validación de credenciales. | Equipo 3 | Laboratorio_Sena | Planeado |
| Ventas | Registra ventas, calcula totales y genera comprobantes. | Equipo 3 | Laboratorio_Sena | Planeado |
| Inventario | Administra productos, existencias y alertas de stock. | Equipo 3 | Laboratorio_Sena | Planeado |
| Proveedores | Gestiona proveedores y pedidos de mercancía. | Equipo 3 | Laboratorio_Sena | Planeado |
| Reportes | Genera reportes diarios y mensuales del sistema. | Equipo 3 | Laboratorio_Sena | Planeado |