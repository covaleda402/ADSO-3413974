# admin-manual

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

<!-- Contenido pendiente -->

## Funciones

El administrador podrá:

- Gestionar usuarios.
- Administrar productos.
- Gestionar inventario.
- Gestionar proveedores.
- Consultar reportes.
- Configurar el sistema.

## Responsabilidades

- Mantener actualizada la información.
- Realizar copias de seguridad.
- Gestionar los usuarios del sistema.