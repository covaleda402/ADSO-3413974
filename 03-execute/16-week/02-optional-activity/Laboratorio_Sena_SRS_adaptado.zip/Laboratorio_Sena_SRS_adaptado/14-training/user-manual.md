# user-manual

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

<!-- Contenido pendiente -->

## Uso del sistema

1. Iniciar sesión.
2. Acceder al menú principal.
3. Seleccionar la funcionalidad requerida.
4. Registrar o consultar información.
5. Cerrar sesión al finalizar.

## Recomendaciones

- No compartir las credenciales.
- Verificar la información antes de guardar.
- Realizar copias de seguridad periódicamente.