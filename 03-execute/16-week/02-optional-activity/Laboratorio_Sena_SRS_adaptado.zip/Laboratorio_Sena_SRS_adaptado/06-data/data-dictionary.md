# data-dictionary

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

<!-- Contenido pendiente -->
# Data Dictionary

## Introducción

El presente diccionario de datos describe las principales entidades utilizadas por el Sistema de Gestión Comercial del Supermercado La Esquina. Su propósito es definir la estructura de la información que será almacenada y administrada por el sistema.

---

# Entidad: Usuario

| Campo | Tipo | Descripción |
|--------|------|-------------|
| id_usuario | INT | Identificador único del usuario. |
| nombre | VARCHAR(100) | Nombre completo del usuario. |
| usuario | VARCHAR(50) | Nombre de inicio de sesión. |
| contraseña | VARCHAR(255) | Contraseña cifrada del usuario. |
| rol | VARCHAR(20) | Rol asignado (Administrador o Cajero). |
| estado | BOOLEAN | Estado del usuario (Activo/Inactivo). |

---

# Entidad: Producto

| Campo | Tipo | Descripción |
|--------|------|-------------|
| id_producto | INT | Identificador único del producto. |
| nombre | VARCHAR(100) | Nombre del producto. |
| categoria | VARCHAR(50) | Categoría del producto. |
| precio | DECIMAL(10,2) | Precio de venta. |
| stock | INT | Cantidad disponible. |
| stock_minimo | INT | Cantidad mínima permitida. |
| id_proveedor | INT | Proveedor del producto. |

---

# Entidad: Proveedor

| Campo | Tipo | Descripción |
|--------|------|-------------|
| id_proveedor | INT | Identificador único del proveedor. |
| nombre | VARCHAR(100) | Nombre del proveedor. |
| nit | VARCHAR(20) | Número de identificación tributaria. |
| telefono | VARCHAR(20) | Teléfono de contacto. |
| correo | VARCHAR(100) | Correo electrónico. |

---

# Entidad: Venta

| Campo | Tipo | Descripción |
|--------|------|-------------|
| id_venta | INT | Identificador de la venta. |
| fecha | DATE | Fecha de la venta. |
| hora | TIME | Hora de la venta. |
| total | DECIMAL(10,2) | Valor total de la venta. |
| cambio | DECIMAL(10,2) | Cambio entregado al cliente. |
| id_usuario | INT | Cajero que realizó la venta. |

---

# Entidad: DetalleVenta

| Campo | Tipo | Descripción |
|--------|------|-------------|
| id_detalle | INT | Identificador del detalle. |
| id_venta | INT | Venta asociada. |
| id_producto | INT | Producto vendido. |
| cantidad | INT | Cantidad vendida. |
| precio_unitario | DECIMAL(10,2) | Precio del producto. |
| subtotal | DECIMAL(10,2) | Valor parcial del producto. |

---

# Entidad: PedidoProveedor

| Campo | Tipo | Descripción |
|--------|------|-------------|
| id_pedido | INT | Identificador del pedido. |
| id_proveedor | INT | Proveedor asociado. |
| fecha | DATE | Fecha del pedido. |
| estado | VARCHAR(20) | Estado del pedido. |
| total | DECIMAL(10,2) | Valor total del pedido. |

---

## Relaciones principales

- Un proveedor puede suministrar varios productos.
- Un usuario puede registrar múltiples ventas.
- Una venta contiene uno o varios productos.
- Cada producto puede participar en múltiples ventas.
- Un proveedor puede tener múltiples pedidos registrados.