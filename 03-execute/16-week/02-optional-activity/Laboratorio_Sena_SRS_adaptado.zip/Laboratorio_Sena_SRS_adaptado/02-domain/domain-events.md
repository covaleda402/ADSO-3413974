
# Domain Events

> Estado: 🔴 | Última actualización: 2026-06-16

## Eventos del dominio

### Venta registrada

Se produce cuando el cajero confirma una venta. El sistema calcula el total, registra la transacción y actualiza el inventario.

### Stock actualizado

Ocurre cuando se registra una venta o una entrada de mercancía, modificando la cantidad disponible de un producto.

### Stock mínimo detectado

Se genera cuando la cantidad disponible de un producto es inferior al stock mínimo configurado, activando una alerta.

### Proveedor registrado

Se produce cuando el administrador registra un nuevo proveedor en el sistema.

### Pedido registrado

Ocurre cuando el administrador realiza un pedido a un proveedor.

### Mercancía recibida

Se produce cuando se confirma la recepción de un pedido, actualizando automáticamente el inventario.

### Reporte generado

Se genera cuando el administrador solicita un reporte diario o mensual de ventas.

