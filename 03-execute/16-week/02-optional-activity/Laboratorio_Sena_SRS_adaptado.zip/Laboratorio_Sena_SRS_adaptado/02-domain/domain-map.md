# Domain Map

> Estado: 🔴 | Última actualización: 2026-06-16

## Mapa del dominio

### Entidades principales

* **Producto:** Artículo disponible para la venta dentro del supermercado.
* **Inventario:** Controla la cantidad disponible de cada producto.
* **Venta:** Registro de una transacción realizada por el cajero.
* **Proveedor:** Empresa o persona que suministra productos al supermercado.
* **Pedido:** Solicitud de productos realizada a un proveedor.
* **Reporte:** Información generada a partir de las ventas e inventario.

## Relaciones

* Una **Venta** incluye uno o varios **Productos**.
* Un **Producto** pertenece al **Inventario**.
* Un **Proveedor** suministra uno o varios **Productos**.
* Un **Pedido** está asociado a un **Proveedor**.
* Un **Pedido** actualiza el **Inventario** al recibir la mercancía.
* Un **Reporte** utiliza información de las **Ventas** y del **Inventario**.
* El **Administrador** gestiona inventario, proveedores y reportes.
* El **Cajero** registra las ventas.

