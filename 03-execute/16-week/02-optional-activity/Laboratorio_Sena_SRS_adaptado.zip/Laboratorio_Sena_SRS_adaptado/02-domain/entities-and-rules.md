# Entities and Rules

> Estado: 🔴 | Última actualización: 2026-06-16

## Entidades

### Producto

**Descripción**
Representa un artículo disponible para la venta en el supermercado.

**Reglas**

* Debe tener un nombre y un precio.
* Debe registrar la cantidad disponible en inventario.
* Puede generar una alerta cuando el stock sea inferior al mínimo establecido.

---

### Venta

**Descripción**
Representa una transacción realizada por el cajero.

**Reglas**

* Debe contener uno o varios productos.
* Calcula automáticamente el total de la compra.
* Calcula el cambio correspondiente.
* Actualiza el inventario al confirmar la venta.

---

### Inventario

**Descripción**
Controla la disponibilidad de los productos.

**Reglas**

* Se actualiza automáticamente después de una venta.
* Se incrementa cuando se registra una entrada de mercancía.
* Debe generar alertas de stock mínimo cuando corresponda.

---

### Proveedor

**Descripción**
Persona o empresa que suministra productos al supermercado.

**Reglas**

* Puede registrar uno o varios pedidos.
* Debe almacenar la información básica del proveedor.

---

### Pedido

**Descripción**
Registro de una solicitud realizada a un proveedor.

**Reglas**

* Debe estar asociado a un proveedor.
* Al confirmar la recepción de la mercancía, actualiza el inventario.

---

### Reporte

**Descripción**
Información generada por el sistema sobre las ventas e inventario.

**Reglas**

* Puede generarse diariamente o mensualmente.
* Solo muestra información registrada en el sistema.
