# Índice de diagramas

| Diagrama | Tipo | Archivo fuente | Exportación | Estado |
|-----------|------|----------------|-------------|--------|
| Caso de Uso | UML | use-case.puml | use-case.png | Pendiente |
| Clases | UML | class-diagram.puml | class-diagram.png | Pendiente |
| Entidad-Relación | UML | er-diagram.puml | er-diagram.png | Pendiente |
| Secuencia - Registrar Venta | UML | sequence-sale.puml | sequence-sale.png | Pendiente |
| Actividad - Proceso de Venta | UML | activity-sale.puml | activity-sale.png | Pendiente |