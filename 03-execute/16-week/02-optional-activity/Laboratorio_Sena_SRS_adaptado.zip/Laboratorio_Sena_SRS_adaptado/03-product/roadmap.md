# Roadmap

> Estado: 🔴 | Última actualización: 2026-06-16

## Versión 1.0 (MVP)

### Objetivo

Desarrollar una versión funcional del sistema que permita gestionar las operaciones principales del supermercado.

### Funcionalidades

* Registro y consulta de ventas.
* Cálculo automático de totales y cambio.
* Control de inventario.
* Alertas de stock mínimo.
* Gestión de proveedores.
* Historial de pedidos.
* Reportes diarios y mensuales.
* Control de acceso por roles.

---

## Versión 2.0

### Funcionalidades previstas

* Integración con facturación electrónica (DIAN).
* Integración con datáfonos o pasarelas de pago.
* Aplicación móvil.
* Versión web.
* Gestión de clientes frecuentes y programas de fidelización.

