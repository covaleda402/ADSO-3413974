# Product Backlog

> Estado: 🔴 | Última actualización: 2026-06-16

| ID    | Historia / Funcionalidad         | Prioridad | Estado    |
| ----- | -------------------------------- | --------- | --------- |
| PB-01 | Registrar ventas                 | Crítica   | Pendiente |
| PB-02 | Buscar productos                 | Crítica   | Pendiente |
| PB-03 | Emitir comprobante de venta      | Alta      | Pendiente |
| PB-04 | Anular venta                     | Media     | Pendiente |
| PB-05 | Consultar inventario             | Crítica   | Pendiente |
| PB-06 | Actualizar stock automáticamente | Crítica   | Pendiente |
| PB-07 | Generar alertas de stock mínimo  | Alta      | Pendiente |
| PB-08 | Registrar entrada de mercancía   | Alta      | Pendiente |
| PB-09 | Gestionar proveedores            | Media     | Pendiente |
| PB-10 | Consultar historial de pedidos   | Media     | Pendiente |
| PB-11 | Generar reporte diario           | Alta      | Pendiente |
| PB-12 | Generar reporte mensual          | Media     | Pendiente |
