/**
 * SUITE DE PRUEBAS END-TO-END (E2E) AUTOMATIZADA
 * Sistema de Gestión de Asistencia SENA
 * Ficha: 3413974 - Análisis y Desarrollo de Software (ADSO)
 * Entorno: Local (http://localhost:3000)
 */

require('dns').setDefaultResultOrder('ipv4first');
require('dotenv').config();
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { Client } = require('pg');

const BASE_URL = process.env.BASE_URL || 'http://localhost:3000';
const DATABASE_URL = process.env.DATABASE_URL || 'postgresql://neondb_owner:npg_yWmF7TLOsg5A@ep-restless-mouse-b52879p7-pooler.c-7.us-east-2.aws.neon.tech/asistencia_sena?sslmode=require';

// Helper de gestión de Cookies
class CookieJar {
  constructor() {
    this.cookies = new Map();
  }

  setFromResponse(response) {
    let setCookieHeaders = [];
    if (typeof response.headers.getSetCookie === 'function') {
      setCookieHeaders = response.headers.getSetCookie();
    } else {
      const single = response.headers.get('set-cookie');
      if (single) setCookieHeaders = [single];
    }

    for (const cookieStr of setCookieHeaders) {
      if (!cookieStr) continue;
      const firstPart = cookieStr.split(';')[0];
      const eqIdx = firstPart.indexOf('=');
      if (eqIdx !== -1) {
        const key = firstPart.substring(0, eqIdx).trim();
        const val = firstPart.substring(eqIdx + 1).trim();
        this.cookies.set(key, val);
      }
    }
  }

  getCookieHeader() {
    const pairs = [];
    for (const [key, val] of this.cookies.entries()) {
      pairs.push(`${key}=${val}`);
    }
    return pairs.join('; ');
  }
}

// Estadísticas de pruebas
const testStats = {
  total: 0,
  passed: 0,
  failed: 0,
  suites: [],
  startTime: Date.now(),
  findings: []
};

function logHeader(text) {
  console.log(`\n========================================================================`);
  console.log(`🧪 ${text}`);
  console.log(`========================================================================`);
}

async function runTest(suiteName, testName, testFn) {
  testStats.total++;
  const start = performance.now();
  try {
    await testFn();
    const duration = (performance.now() - start).toFixed(1);
    testStats.passed++;
    console.log(`  ✅ [PASS] (${duration}ms) ${testName}`);
    return { suite: suiteName, name: testName, status: 'PASS', durationMs: duration };
  } catch (err) {
    const duration = (performance.now() - start).toFixed(1);
    testStats.failed++;
    console.error(`  ❌ [FAIL] (${duration}ms) ${testName}`);
    console.error(`     Error: ${err.message}`);
    testStats.findings.push({
      suite: suiteName,
      test: testName,
      error: err.message
    });
    return { suite: suiteName, name: testName, status: 'FAIL', durationMs: duration, error: err.message };
  }
}

function assert(condition, message) {
  if (!condition) {
    throw new Error(message || 'Assertion failed');
  }
}

// Generador de vector facial unitario sintético de 128 dimensiones
function generateSyntheticFaceDescriptor(seed = 1) {
  const vec = [];
  let sumSq = 0;
  for (let i = 0; i < 128; i++) {
    const val = Math.sin(seed * (i + 1)) * Math.cos(seed * (i + 2));
    vec.push(val);
    sumSq += val * val;
  }
  const norm = Math.sqrt(sumSq);
  return vec.map(v => v / norm); // Vector unitario normalizado
}

// Generador de token rotativo local idéntico al backend (HMAC-SHA256)
function generateRotativeTokenLocal(sessionToken, timeSlotOffset = 0) {
  const timeSlot = Math.floor(Date.now() / 30000) + timeSlotOffset;
  return crypto
    .createHmac('sha256', sessionToken)
    .update(`sena_rotative_slot:${timeSlot}`)
    .digest('hex')
    .substring(0, 32);
}

async function executeAllSuites() {
  console.log(`Iniciando suite integral E2E contra ${BASE_URL}...`);
  const instructorJar = new CookieJar();
  const coordinadorJar = new CookieJar();
  const aprendizJar = new CookieJar();

  let activeSessionData = null;
  let ficha34Id = null;
  let syntheticFaceVector = generateSyntheticFaceDescriptor(42);
  let createdExcuseUnidiaId = null;
  let createdExcuseMultidiaId = null;
  let lateSessionData = null;

  const aprendizDoc = '1077726131';
  const aprendizNombre = 'JOSE ESNEIDER COVALEDA HORTUA';

  // Conexión directa a la BD con reintentos para resiliencia DNS
  async function connectClientWithRetry(connectionString, maxRetries = 5) {
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      const client = new Client({ connectionString, ssl: { rejectUnauthorized: false } });
      try {
        await client.connect();
        return client;
      } catch (err) {
        if (attempt === maxRetries) throw err;
        await new Promise(r => setTimeout(r, 1000 * attempt));
      }
    }
  }

  const pgClient = await connectClientWithRetry(DATABASE_URL);

  // Asegurar que Ficha 3413974 existe y obtener su ID
  const fichaDb = await pgClient.query(`SELECT id FROM fichas WHERE code = '3413974' LIMIT 1`);
  if (fichaDb.rows.length > 0) {
    ficha34Id = fichaDb.rows[0].id;
  }

  // =========================================================================
  // SUITE 1: AUTENTICACIÓN Y CONTROL DE ACCESO BASADO EN ROLES (RBAC)
  // =========================================================================
  logHeader('SUITE 1: AUTENTICACIÓN Y CONTROL DE ACCESO (RBAC)');

  await runTest('SUITE 1', '1.1 Validación de política de aceptación de términos (400 si falta accept_terms)', async () => {
    const res = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        document: '1000200300',
        full_name: 'Carlos Mario Restrepo',
        accept_terms: false
      })
    });
    assert(res.status === 400, `Status esperado 400, recibido ${res.status}`);
    const data = await res.json();
    assert(data.error.includes('términos de tratamiento de datos'), 'Debe exigir aceptación de términos');
  });

  await runTest('SUITE 1', '1.2 Login exitoso de Instructor (Carlos Mario Restrepo)', async () => {
    const res = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        document: '1000200300',
        full_name: 'Carlos Mario Restrepo',
        accept_terms: true
      })
    });
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(data.success === true, 'Respuesta debe contener success: true');
    assert(data.user.role === 'instructor', 'Rol debe ser instructor');
    assert(data.redirect === '/instructor/dashboard', 'Debe redirigir a /instructor/dashboard');
    instructorJar.setFromResponse(res);
    assert(instructorJar.cookies.has('sena_session'), 'Debe establecer la cookie sena_session');
  });

  await runTest('SUITE 1', '1.3 Validación de sesión activa del Instructor (/api/auth/me)', async () => {
    const res = await fetch(`${BASE_URL}/api/auth/me`, {
      headers: { Cookie: instructorJar.getCookieHeader() }
    });
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(data.user.document === '1000200300', 'Documento en sesión no coincide');
    assert(data.user.role === 'instructor', 'Rol de sesión no coincide');
  });

  await runTest('SUITE 1', '1.4 Login exitoso de Coordinador (Diana Carolina Rojas)', async () => {
    const res = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        document: '900800700',
        full_name: 'Diana Carolina Rojas',
        accept_terms: true
      })
    });
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(data.user.role === 'coordinador', 'Rol debe ser coordinador');
    assert(data.redirect === '/coordinador/dashboard', 'Debe redirigir a /coordinador/dashboard');
    coordinadorJar.setFromResponse(res);
    assert(coordinadorJar.cookies.has('sena_session'), 'Debe generar cookie para coordinador');
  });

  await runTest('SUITE 1', '1.5 Intento de login con documento no registrado (401)', async () => {
    const res = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        document: '99999999999',
        full_name: 'Usuario Fantasma',
        accept_terms: true
      })
    });
    assert(res.status === 401, `Status esperado 401, recibido ${res.status}`);
    const data = await res.json();
    assert(data.error.includes('no corresponden a un usuario activo'), 'Debe reportar usuario inexistente');
  });

  await runTest('SUITE 1', '1.6 Intento de login con nombre no coincidente (401)', async () => {
    const res = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        document: '1000200300',
        full_name: 'Pedro Picapiedra',
        accept_terms: true
      })
    });
    assert(res.status === 401, `Status esperado 401, recibido ${res.status}`);
    const data = await res.json();
    assert(data.error.includes('no coincide'), 'Debe reportar que el nombre no coincide');
  });

  await runTest('SUITE 1', '1.7 Instructor intenta acceder a endpoint restringido de Coordinador (403)', async () => {
    const res = await fetch(`${BASE_URL}/api/coordinador/instructores`, {
      headers: { Cookie: instructorJar.getCookieHeader() }
    });
    assert(res.status === 403, `Status esperado 403, recibido ${res.status}`);
  });

  await runTest('SUITE 1', '1.8 Petición no autenticada a API protegida (403)', async () => {
    const res = await fetch(`${BASE_URL}/api/instructor/sessions`);
    assert(res.status === 403, `Status esperado 403, recibido ${res.status}`);
  });

  // =========================================================================
  // SUITE 2: CICLO DE VIDA DE SESIONES QR DEL INSTRUCTOR
  // =========================================================================
  logHeader('SUITE 2: CICLO DE VIDA DE SESIONES QR (INSTRUCTOR)');

  await runTest('SUITE 2', '2.1 Instructor consulta opciones académicas (Fichas y Ambientes)', async () => {
    const res = await fetch(`${BASE_URL}/api/instructor/options`, {
      headers: { Cookie: instructorJar.getCookieHeader() }
    });
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(Array.isArray(data.fichas), 'Debe retornar un array de fichas');
    assert(Array.isArray(data.ambientes), 'Debe retornar un array de ambientes');
    const ficha34 = data.fichas.find(f => f.code === '3413974');
    assert(ficha34, 'Ficha 3413974 debe estar disponible en las opciones del instructor');
    ficha34Id = ficha34.id;
  });

  await runTest('SUITE 2', '2.2 Limpiar sesiones previas activas para aislar prueba', async () => {
    await pgClient.query(`UPDATE qr_sessions SET status = 'finished' WHERE instructor_id = 2 AND status = 'active'`);
  });

  await runTest('SUITE 2', '2.3 Creación de sesión QR regular para Ficha 3413974', async () => {
    const res = await fetch(`${BASE_URL}/api/instructor/sessions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: instructorJar.getCookieHeader()
      },
      body: JSON.stringify({
        ficha_code: '3413974',
        program_name: 'Análisis y Desarrollo de Software',
        jornada: 'Diurna',
        ambiente_name: 'Ambiente 204 - Aula de Software',
        grupo: 'ADSO-G1',
        sede: 'Sede Principal Neiva',
        hours_duration: 6
      })
    });
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(data.success === true, 'Creación de sesión debe ser exitosa');
    assert(data.session.token, 'Sesión debe contener un token único');
    assert(data.session.rotativeToken, 'Sesión debe generar rotativeToken');
    activeSessionData = data.session;
    if (!ficha34Id) ficha34Id = data.session.ficha_id;
  });

  await runTest('SUITE 2', '2.4 Restricción de unicidad: Intentar crear 2da sesión activa concurrente (400)', async () => {
    const res = await fetch(`${BASE_URL}/api/instructor/sessions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: instructorJar.getCookieHeader()
      },
      body: JSON.stringify({
        ficha_code: '2711425',
        jornada: 'Diurna',
        ambiente_name: 'Ambiente 102 - Torre de Redes',
        hours_duration: 6
      })
    });
    assert(res.status === 400, `Status esperado 400, recibido ${res.status}`);
    const data = await res.json();
    assert(data.error.includes('Ya tienes una sesión activa en progreso'), 'Debe advertir de sesión activa');
  });

  await runTest('SUITE 2', '2.5 Consulta de sesión activa (/api/instructor/sessions)', async () => {
    const res = await fetch(`${BASE_URL}/api/instructor/sessions`, {
      headers: { Cookie: instructorJar.getCookieHeader() }
    });
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(data.activeSession !== null, 'activeSession no debe ser nulo');
    assert(data.activeSession.id === activeSessionData.id, 'ID de sesión activa debe coincidir');
  });

  // =========================================================================
  // SUITE 3: ONBOARDING Y ENROLAMIENTO BIOMÉTRICO (APRENDIZ)
  // =========================================================================
  logHeader('SUITE 3: ONBOARDING Y ENROLAMIENTO BIOMÉTRICO');

  await runTest('SUITE 3', '3.1 Consulta de identidad del Aprendiz en acceso (/api/aprendiz/check-identity)', async () => {
    const res = await fetch(`${BASE_URL}/api/aprendiz/check-identity`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        document: aprendizDoc,
        full_name: aprendizNombre
      })
    });
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(data.exists === true, 'El aprendiz debe existir en la base de datos');
    assert(data.aprendiz.document === aprendizDoc, 'Documento validado');
  });

  await runTest('SUITE 3', '3.2 Intento de registro biométrico sin consentimiento informado (400)', async () => {
    const res = await fetch(`${BASE_URL}/api/aprendiz/register-first-time`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        document: aprendizDoc,
        full_name: aprendizNombre,
        ficha_id: ficha34Id,
        biometric_consent: false,
        face_descriptor_json: syntheticFaceVector
      })
    });
    assert(res.status === 400, `Status esperado 400, recibido ${res.status}`);
    const data = await res.json();
    assert(data.error.includes('autorizar de manera libre y expresa'), 'Debe requerir consentimiento obligatorio');
  });

  await runTest('SUITE 3', '3.3 Enrolamiento biométrico exitoso con vector 128D y consentimiento', async () => {
    const res = await fetch(`${BASE_URL}/api/aprendiz/register-first-time`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        document: aprendizDoc,
        full_name: aprendizNombre,
        ficha_id: ficha34Id,
        biometric_consent: true,
        face_descriptor_json: syntheticFaceVector
      })
    });
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(data.success === true, 'Registro biométrico debe ser exitoso');
    aprendizJar.setFromResponse(res);
    assert(aprendizJar.cookies.has('sena_aprendiz_session'), 'Debe emitir cookie sena_aprendiz_session');
  });

  await runTest('SUITE 3', '3.4 Verificación de estado biométrico en BD (/api/aprendiz/check-face-status)', async () => {
    const res = await fetch(`${BASE_URL}/api/aprendiz/check-face-status`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ document: aprendizDoc })
    });
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(data.has_face === true, 'has_face debe ser true tras el enrolamiento');
  });

  // =========================================================================
  // SUITE 4: VERIFICACIÓN FACIAL 128D Y MARCACIÓN DE ASISTENCIA QR
  // =========================================================================
  logHeader('SUITE 4: VERIFICACIÓN FACIAL 128D Y ASISTENCIA');

  await runTest('SUITE 4', '4.1 Consulta de información de sesión por QR (/api/aprendiz/session-info)', async () => {
    const res = await fetch(`${BASE_URL}/api/aprendiz/session-info?token=${activeSessionData.token}`);
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(data.session.ficha_code === '3413974', 'Ficha code coincide');
    assert(data.session.status === 'active', 'Sesión se reporta activa');
  });

  await runTest('SUITE 4', '4.2 Verificación facial con vector distante (persona no coincidente -> 401)', async () => {
    const impostorVector = generateSyntheticFaceDescriptor(999);
    const res = await fetch(`${BASE_URL}/api/aprendiz/verify-face`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        document: aprendizDoc,
        candidate_descriptor: impostorVector
      })
    });
    assert(res.status === 401 || res.status === 403, `Status esperado 401 o 403, recibido ${res.status}`);
    const data = await res.json();
    assert(data.success === false, 'Verificación facial debe fallar para impostor');
  });

  await runTest('SUITE 4', '4.3 Verificación facial con vector coincidente (distancia euclidiana <= 0.55)', async () => {
    const res = await fetch(`${BASE_URL}/api/aprendiz/verify-face`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        document: aprendizDoc,
        candidate_descriptor: syntheticFaceVector
      })
    });
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(data.success === true, 'Verificación facial debe ser exitosa');
    assert(data.distance < 0.05, 'Distancia euclidiana debe ser prácticamente 0');
  });

  await runTest('SUITE 4', '4.4 Violación de geocerca GPS: Marcación con coordenadas lejanas (403)', async () => {
    const rotToken = generateRotativeTokenLocal(activeSessionData.token);
    const res = await fetch(`${BASE_URL}/api/aprendiz/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        token: activeSessionData.token,
        rotative_token: rotToken,
        document: aprendizDoc,
        full_name: aprendizNombre,
        latitud: '6.2442000',
        longitud: '-75.5812000',
        precision_gps: '10m',
        location_status: 'Capturada con éxito'
      })
    });
    assert(res.status === 403, `Status esperado 403 por geocerca violada, recibido ${res.status}`);
    const data = await res.json();
    assert(data.error.includes('Geocerca violada'), 'Debe reportar infracción de geocerca');
  });

  await runTest('SUITE 4', '4.5 Marcación exitosa de asistencia con QR rotativo y GPS válido', async () => {
    const rotToken = generateRotativeTokenLocal(activeSessionData.token);
    const res = await fetch(`${BASE_URL}/api/aprendiz/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        token: activeSessionData.token,
        rotative_token: rotToken,
        document: aprendizDoc,
        full_name: aprendizNombre,
        latitud: '4.6098000',
        longitud: '-74.0816000',
        precision_gps: '5m',
        location_status: 'Capturada con éxito'
      })
    });
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(data.success === true, 'Asistencia registrada');
    assert(data.attendance.estado === 'Presente', 'Estado debe ser Presente');
    assert(data.attendance.registro_tipo === 'puntual', 'Tipo debe ser puntual');
  });

  await runTest('SUITE 4', '4.6 Prevención de duplicados: Segundo intento de marcación en la misma sesión (409)', async () => {
    const rotToken = generateRotativeTokenLocal(activeSessionData.token);
    const res = await fetch(`${BASE_URL}/api/aprendiz/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        token: activeSessionData.token,
        rotative_token: rotToken,
        document: aprendizDoc,
        full_name: aprendizNombre,
        latitud: '4.6098000',
        longitud: '-74.0816000',
        precision_gps: '5m',
        location_status: 'Capturada con éxito'
      })
    });
    assert(res.status === 409, `Status esperado 409, recibido ${res.status}`);
    const data = await res.json();
    assert(data.error.includes('Ya has registrado tu asistencia'), 'Debe rechazar marcación duplicada');
  });

  await runTest('SUITE 4', '4.7 Marcación con token rotativo fraudulento/alterado (410)', async () => {
    const fakeRotToken = 'ffffffffffffffffffffffffffffffff';
    const res = await fetch(`${BASE_URL}/api/aprendiz/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        token: activeSessionData.token,
        rotative_token: fakeRotToken,
        document: '1019992785',
        full_name: 'BRENDA CAROLINA GALEANO RAMIREZ',
        latitud: '4.6098000',
        longitud: '-74.0816000',
        precision_gps: '5m',
        location_status: 'Capturada con éxito'
      })
    });
    assert(res.status === 410, `Status esperado 410, recibido ${res.status}`);
    const data = await res.json();
    assert(data.error.includes('código QR dinámico ha rotado'), 'Debe advertir que el QR dinámico rotó');
  });

  // =========================================================================
  // SUITE 5: QR TARDÍO, FINALIZACIÓN DE SESIÓN Y FALTAS AUTOMÁTICAS
  // =========================================================================
  logHeader('SUITE 5: QR TARDÍO, CIERRE Y FALTAS AUTOMÁTICAS');

  await runTest('SUITE 5', '5.1 Generación de código QR para tardíos (late_qr)', async () => {
    const res = await fetch(`${BASE_URL}/api/instructor/sessions/${activeSessionData.id}/late-qr`, {
      method: 'POST',
      headers: { Cookie: instructorJar.getCookieHeader() }
    });
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(data.success === true, 'Debe generar late_qr exitosamente');
    assert(data.token, 'Debe retornar token de late session');
    assert(data.rotativeToken, 'Debe retornar rotativeToken');
    lateSessionData = data;
  });

  await runTest('SUITE 5', '5.2 Marcación de segundo aprendiz en sesión tardía -> Estado "Tarde"', async () => {
    const secondAprendizDoc = '1019992785';
    const secondAprendizName = 'BRENDA CAROLINA GALEANO RAMIREZ';

    const rotToken = generateRotativeTokenLocal(lateSessionData.token);
    const res = await fetch(`${BASE_URL}/api/aprendiz/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        token: lateSessionData.token,
        rotative_token: rotToken,
        document: secondAprendizDoc,
        full_name: secondAprendizName,
        latitud: '4.6098000',
        longitud: '-74.0816000',
        precision_gps: '5m',
        location_status: 'Capturada con éxito'
      })
    });
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(data.attendance.estado === 'Tarde', 'En sesión tardía el estado debe ser Tarde');
  });

  await runTest('SUITE 5', '5.3 Instructor finaliza la sesión activa (/api/instructor/sessions/[id]/finish)', async () => {
    const res = await fetch(`${BASE_URL}/api/instructor/sessions/${activeSessionData.id}/finish`, {
      method: 'POST',
      headers: { Cookie: instructorJar.getCookieHeader() }
    });
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(data.success === true, 'Sesión finalizada exitosamente');
  });

  await runTest('SUITE 5', '5.4 Verificación en BD: Generación automática de faltas para aprendices no asistentes', async () => {
    const dbRes = await pgClient.query(
      `SELECT estado, registro_tipo, COUNT(*)::int as cantidad 
       FROM attendances 
       WHERE qr_session_id = $1 
       GROUP BY estado, registro_tipo`,
      [activeSessionData.id]
    );
    const counts = {};
    for (const row of dbRes.rows) {
      counts[`${row.estado}_${row.registro_tipo}`] = row.cantidad;
    }
    console.log('    -> Conteo en BD de sesión:', counts);
    assert(counts['Presente_puntual'] >= 1, 'Debe haber al menos 1 asistencia puntual');
    assert(counts['Falta_ausencia_automatica'] >= 28, 
      `Faltas automáticas generadas esperadas >= 28, recibidas ${counts['Falta_ausencia_automatica']}`);
  });

  await runTest('SUITE 5', '5.5 Intento de registro en sesión ya finalizada (410)', async () => {
    const rotToken = generateRotativeTokenLocal(activeSessionData.token);
    const res = await fetch(`${BASE_URL}/api/aprendiz/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        token: activeSessionData.token,
        rotative_token: rotToken,
        document: '1029881661',
        full_name: 'ANDRES FERNANDO SALINAS VARGAS',
        latitud: '4.6098000',
        longitud: '-74.0816000',
        precision_gps: '5m',
        location_status: 'Capturada con éxito'
      })
    });
    assert(res.status === 410, `Status esperado 410, recibido ${res.status}`);
  });

  // =========================================================================
  // SUITE 6: ROSTER, GESTIÓN DE APRENDICES Y REGISTRO MANUAL
  // =========================================================================
  logHeader('SUITE 6: ROSTER Y GESTIÓN DEL INSTRUCTOR');

  await runTest('SUITE 6', '6.1 Consulta del Roster de la Ficha 3413974 (/api/instructor/roster?ficha_code=3413974)', async () => {
    const res = await fetch(`${BASE_URL}/api/instructor/roster?ficha_code=3413974`, {
      headers: { Cookie: instructorJar.getCookieHeader() }
    });
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(Array.isArray(data.aprendices), 'Debe devolver lista de aprendices');
    assert(data.aprendices.length === 30, `La ficha debe tener 30 aprendices, tiene ${data.aprendices.length}`);
    const covaleda = data.aprendices.find(a => a.document === aprendizDoc);
    assert(covaleda, 'Jose Covaleda debe estar en el listado del roster');
    assert(covaleda.full_name.includes('COVALEDA'), 'Nombre verificado en roster');
  });

  await runTest('SUITE 6', '6.2 Registro manual de tardanza justificada por el instructor', async () => {
    const thirdDoc = '1075795095';
    const thirdName = 'MARTIN JULIAN TORRES FIERRO';
    const res = await fetch(`${BASE_URL}/api/instructor/attendances/manual-late`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: instructorJar.getCookieHeader()
      },
      body: JSON.stringify({
        session_id: activeSessionData.id,
        aprendiz_name: thirdName,
        aprendiz_document: thirdDoc,
        arrival_time: '08:35 AM',
        estado: 'Justificado',
        horas: 6,
        excuse_note: 'Permiso médico autorizado por coordinación'
      })
    });
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(data.success === true, 'Registro manual exitoso');
    assert(data.attendance.estado === 'Justificado', 'Estado debe ser Justificado');
  });

  // =========================================================================
  // SUITE 7: FLUJO TRANSACCIONAL DE EXCUSAS Y CONCURRENCIA OPTIMISTA
  // =========================================================================
  logHeader('SUITE 7: EXCUSAS Y CONCURRENCIA OPTIMISTA');

  await runTest('SUITE 7', '7.1 Radicación de Excusa Unidía (1 día) con adjunto PDF sintético', async () => {
    const dummyPdfContent = '%PDF-1.4\n1 0 obj\n<< /Title (Certificado Medico) >>\nendobj\ntrailer\n<< /Root 1 0 R >>\n%%EOF';
    const blob = new Blob([dummyPdfContent], { type: 'application/pdf' });
    const formData = new FormData();
    formData.append('ficha_id', String(ficha34Id));
    formData.append('start_date', '2026-11-20');
    formData.append('end_date', '2026-11-20'); // Unidía
    formData.append('reason', 'Cita médica odontológica programada en EPS Sura');
    formData.append('file', blob, 'incapacidad_unidia.pdf');

    const res = await fetch(`${BASE_URL}/api/aprendiz/excusas/upload`, {
      method: 'POST',
      headers: { Cookie: aprendizJar.getCookieHeader() },
      body: formData
    });
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(data.success === true, 'Excusa unidía radicada');
    assert(data.tipo === 'unidía', 'Tipo debe ser unidía');
    createdExcuseUnidiaId = data.excuse_id;
  });

  await runTest('SUITE 7', '7.2 Radicación de Excusa Multidía (3 días) remitida a Coordinación', async () => {
    const dummyPngBytes = new Uint8Array([137, 80, 78, 71, 13, 10, 26, 10, 0, 0, 0, 13, 73, 72, 68, 82]);
    const blob = new Blob([dummyPngBytes], { type: 'image/png' });
    const formData = new FormData();
    formData.append('ficha_id', String(ficha34Id));
    formData.append('start_date', '2026-11-20');
    formData.append('end_date', '2026-11-23'); // Multidía
    formData.append('reason', 'Incapacidad médica por intervención quirúrgica ambulatoria');
    formData.append('file', blob, 'incapacidad_multidia.png');

    const res = await fetch(`${BASE_URL}/api/aprendiz/excusas/upload`, {
      method: 'POST',
      headers: { Cookie: aprendizJar.getCookieHeader() },
      body: formData
    });
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(data.tipo === 'multidía', 'Tipo debe ser multidía');
    createdExcuseMultidiaId = data.excuse_id;
  });

  await runTest('SUITE 7', '7.3 Instructor intenta revisar excusa multidía (restringido a Coordinación)', async () => {
    const res = await fetch(`${BASE_URL}/api/instructor/excusas/${createdExcuseMultidiaId}/review`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: instructorJar.getCookieHeader()
      },
      body: JSON.stringify({
        action: 'approved',
        version: 1,
        instructor_comment: 'Aprobado por instructor'
      })
    });
    assert(res.status >= 400, `Debe rechazar con código >= 400, recibido ${res.status}`);
    const data = await res.json();
    assert(data.error.includes('Coordinación Académica'), 'Debe indicar que requiere aprobación de coordinación');
  });

  await runTest('SUITE 7', '7.4 Instructor aprueba excusa Unidía (Versión 1 -> 2)', async () => {
    const res = await fetch(`${BASE_URL}/api/instructor/excusas/${createdExcuseUnidiaId}/review`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: instructorJar.getCookieHeader()
      },
      body: JSON.stringify({
        action: 'approved',
        version: 1,
        instructor_comment: 'Soporte EPS validado y conforme'
      })
    });
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(data.newVersion === 2, `La nueva versión debe ser 2, recibida ${data.newVersion}`);
  });

  await runTest('SUITE 7', '7.5 Bloqueo Optimista: Reintento con versión obsoleta version=1 (409 Conflict)', async () => {
    const res = await fetch(`${BASE_URL}/api/instructor/excusas/${createdExcuseUnidiaId}/review`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: instructorJar.getCookieHeader()
      },
      body: JSON.stringify({
        action: 'rejected',
        version: 1, // Versión obsoleta! En BD ya está en versión 2
        instructor_comment: 'Intento de sobreescritura concurrente desfasada'
      })
    });
    assert(res.status === 409, `Status esperado 409 Conflict, recibido ${res.status}`);
    const data = await res.json();
    assert(data.error.toLowerCase().includes('conflicto') || data.error.toLowerCase().includes('concurrencia'), 
      'Debe indicar conflicto de concurrencia');
  });

  await runTest('SUITE 7', '7.6 Coordinador aprueba excusa Multidía (Versión 1 -> 2)', async () => {
    const res = await fetch(`${BASE_URL}/api/coordinador/excusas/${createdExcuseMultidiaId}/review`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: coordinadorJar.getCookieHeader()
      },
      body: JSON.stringify({
        action: 'approved',
        version: 1,
        instructor_comment: 'Aprobación institucional por Coordinación Académica'
      })
    });
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(data.newVersion === 2, 'Coordinador incrementa versión a 2');
  });

  // =========================================================================
  // SUITE 8: HISTORIAL, REPORTES Y TRAZABILIDAD DE AUDITORÍA
  // =========================================================================
  logHeader('SUITE 8: AUDITORÍA Y REPORTES');

  await runTest('SUITE 8', '8.1 Historial de sesiones del instructor (/api/instructor/history)', async () => {
    const res = await fetch(`${BASE_URL}/api/instructor/history?page=1&limit=10`, {
      headers: { Cookie: instructorJar.getCookieHeader() }
    });
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(Array.isArray(data.sessions), 'Debe incluir lista de sesiones');
    assert(data.sessions.length > 0, 'Debe haber al menos 1 sesión en el historial');
  });

  await runTest('SUITE 8', '8.2 Historial global del Coordinador (/api/coordinador/history)', async () => {
    const res = await fetch(`${BASE_URL}/api/coordinador/history?page=1&limit=10`, {
      headers: { Cookie: coordinadorJar.getCookieHeader() }
    });
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(Array.isArray(data.sessions), 'Coordinador ve lista histórica');
  });

  await runTest('SUITE 8', '8.3 Historial personal de asistencias del Aprendiz (/api/aprendiz/my-attendance?document=...)', async () => {
    const res = await fetch(`${BASE_URL}/api/aprendiz/my-attendance?document=${aprendizDoc}`, {
      headers: { Cookie: aprendizJar.getCookieHeader() }
    });
    assert(res.status === 200, `Status esperado 200, recibido ${res.status}`);
    const data = await res.json();
    assert(Array.isArray(data.attendances), 'Aprendiz ve sus asistencias');
    assert(data.attendances.length >= 1, 'Jose Covaleda ve su asistencia registrada');
  });

  await runTest('SUITE 8', '8.4 Verificación de persistencia en tabla audit_events (PostgreSQL)', async () => {
    const auditRes = await pgClient.query(`
      SELECT event_type, actor_role, target_entity, COUNT(*)::int as total
      FROM audit_events
      GROUP BY event_type, actor_role, target_entity
    `);
    assert(auditRes.rows.length > 0, 'La tabla audit_events debe registrar eventos');
    console.log('    -> Eventos de auditoría registrados:', auditRes.rows);
  });

  // =========================================================================
  // SUITE 9: INTERFAZ DE USUARIO Y ASSETS ESTÁTICOS (UI HEALTH CHECK)
  // =========================================================================
  logHeader('SUITE 9: INTERFACES WEB (UI HEALTH CHECK)');

  const uiRoutes = [
    { url: '/login', name: 'Login Page' },
    { url: '/scan', name: 'QR Scan Page' },
    { url: '/aprendiz/acceso', name: 'Aprendiz Acceso Portal' },
    { url: '/aprendiz/primera-vez', name: 'Aprendiz Biometric Onboarding Page' },
    { url: '/instructor/dashboard', name: 'Instructor Dashboard', jar: instructorJar },
    { url: '/coordinador/dashboard', name: 'Coordinador Dashboard', jar: coordinadorJar },
    { url: '/aprendiz/dashboard', name: 'Aprendiz Dashboard', jar: aprendizJar }
  ];

  for (const page of uiRoutes) {
    await runTest('SUITE 9', `9.x Renderizado HTTP 200: ${page.name} (${page.url})`, async () => {
      const headers = page.jar ? { Cookie: page.jar.getCookieHeader() } : {};
      const res = await fetch(`${BASE_URL}${page.url}`, { headers });
      assert(res.status === 200, `Status esperado 200 en ${page.url}, recibido ${res.status}`);
      const text = await res.text();
      assert(text.includes('<!DOCTYPE html>') || text.includes('<html'), 'Debe retornar documento HTML válido');
    });
  }

  await pgClient.end();

  // Resumen final
  const totalDuration = ((Date.now() - testStats.startTime) / 1000).toFixed(2);
  logHeader('RESUMEN DE RESULTADOS DE PRUEBAS E2E');
  console.log(`Total de pruebas ejecutadas: ${testStats.total}`);
  console.log(`Pruebas superadas (PASS):    ${testStats.passed}`);
  console.log(`Pruebas fallidas  (FAIL):    ${testStats.failed}`);
  console.log(`Tiempo total de ejecución:   ${totalDuration} s`);
  console.log(`Tasa de éxito:               ${((testStats.passed / testStats.total) * 100).toFixed(1)}%`);

  if (testStats.failed > 0) {
    console.log('\nHallazgos / Fallos registrados:');
    testStats.findings.forEach((f, idx) => {
      console.log(`  ${idx + 1}. [${f.suite}] ${f.test} -> ${f.error}`);
    });
  }
}

executeAllSuites().catch(err => {
  console.error('Error fatal durante la ejecución de pruebas E2E:', err);
  process.exit(1);
});
